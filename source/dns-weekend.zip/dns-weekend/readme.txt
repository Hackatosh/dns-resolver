The .py files contain the exact same code as the .ipynb files. They're just there so that part_2 can import code from part_1 more easily
